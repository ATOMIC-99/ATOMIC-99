document.addEventListener('DOMContentLoaded', function () {
    const downloadBtn = document.getElementById('downloadBtn');
    const printBtn = document.getElementById('printBtn');
    const pdfViewer = document.getElementById('pdfViewer');
    const pdfUrl = 'your.pdf'; 
    // URL or path to your PDF

    // Logic for downloading the PDF
    downloadBtn.addEventListener('click', function () {
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.download = 'your.pgf';  // Filename for the download
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        alert('The PDF is being downloaded.');
    });

    // Logic for printing the PDF
    printBtn.addEventListener('click', function () {
        if (confirm('Do you want to print the PDF?')) {
            const iframe = document.createElement('iframe');
            iframe.style.position = 'absolute';
            iframe.style.width = '0';
            iframe.style.height = '0';
            iframe.style.border = 'none';
            iframe.src = pdfUrl;
            document.body.appendChild(iframe);

            iframe.contentWindow.focus();
            iframe.contentWindow.print();

            document.body.removeChild(iframe);
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {
    const slider = document.getElementById('slider');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    let currentIndex = 0;
    const totalSlides = slider.children.length;

    // Function to update the slide position
    function updateSlidePosition() {
        const offset = -currentIndex * 100 / totalSlides;
        slider.style.transform = `translateX(${offset}%)`;
    }

    // Function to move to the next slide
    function moveToNextSlide() {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateSlidePosition();
    }

    // Function to move to the previous slide
    function moveToPrevSlide() {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
        updateSlidePosition();
    }

    // Event listeners for buttons
    nextBtn.addEventListener('click', moveToNextSlide);
    prevBtn.addEventListener('click', moveToPrevSlide);
});
