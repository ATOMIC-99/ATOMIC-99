// Elements
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const loginToggle = document.getElementById('loginToggle');
const signupToggle = document.getElementById('signupToggle');
const switchToSignup = document.getElementById('switchToSignup');
const switchToLogin = document.getElementById('switchToLogin');

// Show login form
function showLoginForm() {
    signupForm.classList.remove('active');
    loginForm.classList.add('active');
}

// Show signup form
function showSignupForm() {
    loginForm.classList.remove('active');
    signupForm.classList.add('active');
}

// Event Listeners
loginToggle.addEventListener('click', showLoginForm);
signupToggle.addEventListener('click', showSignupForm);
switchToSignup.addEventListener('click', showSignupForm);
switchToLogin.addEventListener('click', showLoginForm);

// Initialize
showLoginForm();  // Start with the login form by default

// Signup Function
function signup() {
    const username = document.getElementById('signupUsername').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;

    if (username && email && password) {
        // Create user object
        const user = {
            username: username,
            email: email,
            password: password,
        };

        // Store user data in localStorage
        localStorage.setItem(username, JSON.stringify(user));

        alert('Signup successful! You can now log in.');

        // Clear form
        document.getElementById('signupUsername').value = '';
        document.getElementById('signupEmail').value = '';
        document.getElementById('signupPassword').value = '';

        showLoginForm(); // Switch to login form after signup
    } else {
        alert('Please fill out all fields.');
    }
}

// Login Function
function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    // Retrieve user data from localStorage
    const user = JSON.parse(localStorage.getItem(username));

    if (user && user.password === password) {
        alert('Login successful! Welcome, ' + user.username);
        
        // Clear form
        document.getElementById('loginUsername').value = '';
        document.getElementById('loginPassword').value = '';

        // Redirect or show authenticated content
     window.location.href = 'index.html'; // Example redirect
       

        }
       
       
        
    
    
    
    else {
        alert('Login failed. Please check your username and password.');
    }
}



/*


document.getElementById("yes-btn").addEventListener("click", function() {
    window.location.href = "index.html"; // Redirect to the new page
});


*/


/*

function showAlert() 
        
        {


if (confirm("Do you want to go to the new page?"))
     {
    window.location.href = "index.html";
    
            } 
            
            else 
            
            {
     window.location.href = "https://www.google.com";
     
            }
        }
        
        
        */
        
   